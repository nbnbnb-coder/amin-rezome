from balethon import Client
from balethon.conditions import private, equals
from balethon.objects import ReplyKeyboard
from datetime import datetime as dt

from config import *
from ai import *
from database import *

bot = Client(TOKEN)

init_db()

active_chatters = set()


def check_and_reset_daily(user_id):
    """Check if daily reset is needed and do it for the user"""
    user = get_user(user_id)
    if user:
        messages_left, is_premium, last_reset_date = user
        today = dt.now().date().isoformat()

        if is_premium == 0 and last_reset_date != today:
            # Reset messages for this user
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute("UPDATE users SET messages_left = 5, last_reset_date = ? WHERE user_id = ?",
                      (today, user_id))
            conn.commit()
            conn.close()
            return True  # Reset happened
    return False  # No reset needed


@bot.on_message(private & equals("/start"))
def main(message):
    register_user(message.author.id)  # استفاده از author.id
    message.reply(
        "به هوش مصنوعی خوش آمدید\n\nشما در اشتراک رایگان ۵ پیام رایگان روزانه دارید.",
        ReplyKeyboard(
            ["شروع چت"],
            ["خرید مدل های دیگر"]
        )
    )


@bot.on_message(private & equals("شروع چت"))
def free_chat_start(message):
    user_id = message.author.id  # ذخیره آی‌دی کاربر
    user = get_user(user_id)

    if user:
        # Check and reset daily messages
        check_and_reset_daily(user_id)

        # Get updated user data
        user = get_user(user_id)
        messages_left, is_premium, _ = user

        if is_premium == 1:
            active_chatters.add(user_id)
            message.reply("شما کاربر ویژه هستید. پیام خود را ارسال کنید.")
        elif is_premium == 2:
            active_chatters.add(user_id)
            message.reply("شما کاربر ویژه هستید. پیام خود را ارسال کنید.")
        elif is_premium == 3:
            active_chatters.add(user_id)
            message.reply("متن خود را به انگلیسی ارسال کنید تا عکس ساخته شود.")
        elif messages_left > 0:
            active_chatters.add(user_id)
            message.reply(f"پیام خود را ارسال کنید. (پیام‌های باقی‌مانده امروز: {messages_left})")
        else:
            message.reply("سهمیه پیام‌های رایگان امروز شما تمام شده! فردا دوباره می‌توانید استفاده کنید.")
    else:
        message.reply("لطفا ابتدا دستور /start را بزنید.")


@bot.on_message(private & equals("خرید مدل های دیگر"))
def buy_models(message):
    message.reply("""برای خرید هوش مصنوعی ها عدد مورد نظر رو به @py_mc_amin ارسال کنید:

۱. کویین ۴۵۰۰۰ تومان
تعداد پیام درروز: نامحدود
۲. چت جی پی تی ۹۰۰۰۰ تومان
تعداد پیام درروز: ۱۰۰
۳. عکس ساز ۸۵۰۰۰ تومان
تعداد پیام درروز: ۱۰

توجه : همه اشتراک ها ماهانه هستند.""")


@bot.on_message(private)
def result(message):
    user_id = message.author.id  # استفاده از author.id برای چک کردن در active_chatters

    if user_id in active_chatters:
        user = get_user(user_id)
        if not user:
            message.reply("لطفا ابتدا /start را بزنید.")
            active_chatters.remove(user_id)
            return

        messages_left, is_premium, last_reset_date = user

        # Check and reset daily messages
        check_and_reset_daily(user_id)

        # Get updated user data after potential reset
        user = get_user(user_id)
        messages_left, is_premium, _ = user

        time_now = dt.now().hour
        if not (12 <= time_now < 0):
            message.reply("ربات از ساعت 12 تا 12 باز است!")
            active_chatters.remove(user_id)
            return

        if is_premium == 0 and messages_left <= 0:
            message.reply("سهمیه امروز شما تمام شده است! فردا دوباره امتحان کنید.")
            active_chatters.remove(user_id)
            return
        elif is_premium == 2 and messages_left <= -95:
            message.reply("سهمیه امروز شما تمام شده است! فردا دوباره امتحان کنید.")
            active_chatters.remove(user_id)
            return
        elif is_premium == 3 and messages_left <= -5:
            message.reply("سهمیه امروز شما تمام شده است! فردا دوباره امتحان کنید.")
            active_chatters.remove(user_id)
            return

        try:
            m = message.reply("در حال فکر کردن...")
            re = qwen(message.text)
            m.edit_text(re)

            if is_premium == 0:
                use_message(user_id)  # استفاده از user_id

            # Check if user has no messages left
            updated_user = get_user(user_id)
            if updated_user and updated_user[0] <= 0 and updated_user[1] == 0:
                active_chatters.remove(user_id)
                message.reply("❗️ سهمیه امروز شما تمام شد. فردا می‌توانید دوباره استفاده کنید.")
            elif updated_user and updated_user[0] <= -95 and updated_user[1] == 2:
                active_chatters.remove(user_id)
                message.reply("❗️ سهمیه امروز شما تمام شد. فردا می‌توانید دوباره استفاده کنید.")
            elif updated_user and updated_user[0] <= -5 and updated_user[1] == 3:
                active_chatters.remove(user_id)
                message.reply("❗️ سهمیه امروز شما تمام شد. فردا می‌توانید دوباره استفاده کنید.")

        except Exception as e:
            message.reply("خطایی در پردازش رخ داد.")
            print(f"Error: {e}")


bot.run()
