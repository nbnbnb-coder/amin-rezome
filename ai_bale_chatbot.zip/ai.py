from openai import OpenAI


def qwen(c):
    client = OpenAI(base_url="https://api.gapgpt.app/v1", api_key="TOKEN")

    response = client.chat.completions.create(
        model="gapgpt-qwen-3.6",
        messages=[{"role": "user", "content": c}]
    )
    return response.choices[0].message.content.replace("**", "*")


def chatgpt(c):
    client = OpenAI(base_url="https://api.gapgpt.app/v1", api_key="TOKEN")

    response = client.chat.completions.create(
        model="gpt-5.2-chat-latest",
        messages=[{"role": "user", "content": c}]
    )
    return response.choices[0].message.content.replace("**", "*")


def z_img(c):
    client = OpenAI(base_url="https://api.gapgpt.app/v1", api_key="TOKEN")

    response = client.chat.completions.create(
        model="gapgpt/z-image",
        messages=[{"role": "user", "content": c}]
    )
    return f"""آدرس عکس شما : {response.choices[0].message.content.replace("**", "*")}"""
