import sqlite3
from datetime import datetime


def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (user_id INTEGER PRIMARY KEY, 
                  messages_left INTEGER, 
                  is_premium INTEGER,
                  last_reset_date TEXT)''')
    conn.commit()
    conn.close()


def get_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT messages_left, is_premium, last_reset_date FROM users WHERE user_id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user


def register_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    ip = 1 if user_id == 80301814 else 0
    today = datetime.now().date().isoformat()
    c.execute("INSERT OR IGNORE INTO users (user_id, messages_left, is_premium, last_reset_date) VALUES (?, ?, ?, ?)",
              (user_id, 5, ip, today))
    conn.commit()
    conn.close()


def use_message(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE users SET messages_left = messages_left - 1 WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()


def reset_daily_messages():
    """Reset messages for all non-premium users if last reset was not today"""
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    today = datetime.now().date().isoformat()

    # Reset messages for users whose last reset is not today
    c.execute("UPDATE users SET messages_left = 5, last_reset_date = ? WHERE is_premium = 0 AND last_reset_date != ?",
              (today, today))
    conn.commit()
    conn.close()
