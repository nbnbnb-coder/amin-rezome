from ursina import *
import random as r
from ursina.prefabs.first_person_controller import FirstPersonController
from tkinter import messagebox as ms
from pyautogui import *

# ms.showinfo("info", "WASD to move")
# ms.showinfo("info", "F5 to reload")
# ms.showinfo("info", "1,2,3 to change block")
# ms.showinfo("info", "mouse clicks to add/delete block")
# ms.showinfo("info", "q to quit")

app = Ursina()
player = FirstPersonController()
player.position = (24, 0, 24)
player.rotation = (0, -135, 0)
Sky()

colors = [
    "grass.png",
    "break.png",
    "stone.png",
    "break2.png",
]
c_c = colors[0]
boxes = []
for i in range(22):
    for j in range(22):
        box = Button(
            color=color.white,
            model='cube',
            position=(j, 0, i),
            texture=c_c,
            parent=scene,
            origin_y=0.5,
        )
        boxes.append(box)

for i in range(25):
    for j in range(25):
        box = Button(
            color=color.white,
            model='cube',
            position=(j, -1, i),
            texture=colors[2],
            parent=scene,
            origin_y=0.5,
        )
        boxes.append(box)


def input(key):
    global c_c
    for b in boxes:
        if b.hovered:
            if key == 'left mouse down':
                new = Button(
                    color=color.white,
                    model='cube',
                    position=b.position + mouse.normal,
                    texture=c_c,
                    parent=scene,
                    origin_y=0.5,
                )
                boxes.append(new)
            elif key == 'right mouse down':
                boxes.remove(b)
                destroy(b)
        elif key == '1':
            c_c = colors[0]
        elif key == '2':
            c_c = colors[1]
        elif key == '3':
            c_c = colors[2]
        elif key == '4':
            c_c = colors[3]
        elif key == 'q':
            quit()
        elif player.position <= -30:
            press("f5")



app.run()
