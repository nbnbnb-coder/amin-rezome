import cv2 as cv
import pyautogui as pag

cam = cv.VideoCapture(0)

eye_model = cv.CascadeClassifier('haarcascade_eye.xml')
face_model = cv.CascadeClassifier('haarcascade_frontalface_default.xml')

loop = True

while loop:
    try:
        _, img = cam.read()
        img = cv.flip(img, 1)
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        face = face_model.detectMultiScale(gray)
        color = [(0, 255, 0), (250, 250, 250)]

        x = face[0][0]
        y = face[0][1]
        x2 = x + face[0][2]
        y2 = y + face[0][3]
        gray_face = gray[y:y2, x:x2]
        eye = eye_model.detectMultiScale(gray_face, minSize=(30, 30), scaleFactor=1.1, minNeighbors=5)
        imgout = img.copy()


        mp = pag.position()
        if x < 200 or x2 > 450 or y < 80 or y2 > 350:
            gx = 0
            gy = 0
            if x < 200:
                gx = -abs(x - 200)
            if x2 > 450:
                gx = abs(x2 - 450)
            if y < 80:
                gy = -abs(y - 80)
            if y2 > 350:
                gy = abs(y2 - 350)
            color[0] = color[1] = (100, 100, 0)
            pag.moveTo(mp.x + gx, mp.y + gy, 0.2)

        out = cv.rectangle(imgout, (x, y), (x2, y2), color[0], 3)
        hz = cv.rectangle(out, (200, 80), (450, 350), color[1], 3)

        ic = 0
        for (xe, ye, w, h) in eye:
            ic += 1
            cv.rectangle(imgout, (xe + x, ye + y), (xe + w + x, ye + h + y), (0, 0, 255), 2)
            if ic == 2:
                break

        cv.imshow('amin', out)

        if cv.waitKey(1) == ord('q'):
            loop = False
            cv.destroyAllWindows()
            cam.release()
            break
        elif cv.waitKey(1) == ord('w'):
            pag.click(button='right')
        elif cv.waitKey(1) == ord('a'):
            pag.click()
    except IndexError:
        pass
