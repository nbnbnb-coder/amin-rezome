# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['C:\\Users\\Citx\\Desktop\\amin\\programing\\python\\Projects\\Multiple games in one environment\\دوز\\main.py'],
    pathex=[],
    binaries=[],
    datas=[('images', 'images/')],
    hiddenimports=['customtkinter', 'game_frame', 'random', 'main_frame', 'score_frame', 'player_frame', 'PIL', 'tkinter', 'place_frame', 'sys', 'os'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='دوز',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['images\\Untitled.png'],
)
