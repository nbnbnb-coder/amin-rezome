import customtkinter as ctk


class PlayerFrame(ctk.CTkFrame):
    def __init__(self, master, x_img, o_img, current_player_var, **kwargs):
        # Initialize frame and setup layout
        super().__init__(master, **kwargs)

        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.persian_font = ctk.CTkFont('Arabic Typesetting', 100, 'bold')

        self.text_label = ctk.CTkLabel(self, text='نوبت :', font=self.persian_font)
        self.text_label.grid(column=0, row=0, sticky='nsew')

        self.x_img = x_img
        self.o_img = o_img
        self.current_player_var = current_player_var

        initial_image = x_img if current_player_var.get() == 'X' else o_img
        self.image_label = ctk.CTkLabel(self, text='', image=initial_image)
        self.image_label.grid(column=1, row=0, sticky='nsew')

        current_player_var.trace_add('write', self._update_image)

    def _update_image(self, *args):
        current = self.current_player_var.get()
        if current == 'X':
            self.image_label.configure(image=self.x_img)
        else:
            self.image_label.configure(image=self.o_img)