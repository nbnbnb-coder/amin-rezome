import customtkinter as ctk
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from .place_frame import PlaceFrame


class MainFrame(ctk.CTkFrame):
    def __init__(self, master, x, o, state, func, func2, **kwargs):
        super().__init__(master, **kwargs)

        # griding
        self.grid_columnconfigure((0, 1, 2), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # function
        def grid_all():
            self.place_frame1.grid(column=0, row=0, sticky='nsew')
            self.place_frame2.grid(column=1, row=0, sticky='nsew')
            self.place_frame3.grid(column=2, row=0, sticky='nsew')
            self.place_frame4.grid(column=0, row=1, sticky='nsew')
            self.place_frame5.grid(column=1, row=1, sticky='nsew')
            self.place_frame6.grid(column=2, row=1, sticky='nsew')
            self.place_frame7.grid(column=0, row=2, sticky='nsew')
            self.place_frame8.grid(column=1, row=2, sticky='nsew')
            self.place_frame9.grid(column=2, row=2, sticky='nsew')

        def show_number(value):
            if value == 'del':
                self.time_lbl.destroy()
                grid_all()
            else:
                self.time_lbl.configure(text=value)

        def countdown():
            self.time_lbl.grid(column=1, row=1, padx=10, pady=10, sticky='nsew')
            show_number('۳')

            self.master.after(1000, lambda: show_number('۲'))
            self.master.after(2000, lambda: show_number('۱'))
            self.master.after(3000, lambda: show_number('del'))

        def start():
            self.start_btn.destroy()
            countdown()

        # objects
        self.persian_font = ctk.CTkFont('Arabic Typesetting', 100, 'bold')

        self.start_btn = ctk.CTkButton(self, text='شروع', font=self.persian_font, command=start)
        self.start_btn.grid(column=1, row=1, padx=10, pady=10, sticky='nsew')

        self.time_lbl = ctk.CTkLabel(self, font=self.persian_font)

        self.num = 0

        self.func = func
        self.func2 = func2

        self.winner = None

        self.place_frame1 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame2 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame3 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame4 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame5 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame6 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame7 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame8 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')
        self.place_frame9 = PlaceFrame(self, x, o, state, border_width=5, border_color='red', fg_color='gray')

        self.place_frame1.bind("<Button-1>", self.add_num)
        self.place_frame2.bind("<Button-1>", self.add_num)
        self.place_frame3.bind("<Button-1>", self.add_num)
        self.place_frame4.bind("<Button-1>", self.add_num)
        self.place_frame5.bind("<Button-1>", self.add_num)
        self.place_frame6.bind("<Button-1>", self.add_num)
        self.place_frame7.bind("<Button-1>", self.add_num)
        self.place_frame8.bind("<Button-1>", self.add_num)
        self.place_frame9.bind("<Button-1>", self.add_num)
        self.place_frame1.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame2.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame3.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame4.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame5.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame6.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame7.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame8.img_lbl.bind("<Button-1>", self.add_num)
        self.place_frame9.img_lbl.bind("<Button-1>", self.add_num)

    def check_winner(self):
        # save states
        board = [
            [self.place_frame1.return_state(), self.place_frame2.return_state(), self.place_frame3.return_state()],
            [self.place_frame4.return_state(), self.place_frame5.return_state(), self.place_frame6.return_state()],
            [self.place_frame7.return_state(), self.place_frame8.return_state(), self.place_frame9.return_state()]
        ]

        # row
        for i in range(3):
            if board[i][0] == board[i][1] == board[i][2] and board[i][0] is not None:
                return board[i][0]  # بازگرداندن 'X' یا 'O'

        # column
        for j in range(3):
            if board[0][j] == board[1][j] == board[2][j] and board[0][j] is not None:
                return board[0][j]

        # Main diameter
        if board[0][0] == board[1][1] == board[2][2] and board[0][0] is not None:
            return board[0][0]

        # opposite diameter
        if board[0][2] == board[1][1] == board[2][0] and board[0][2] is not None:
            return board[0][2]

        return None  # no winner

    def reset_all_frames(self):
        self.place_frame1.reset()
        self.place_frame2.reset()
        self.place_frame3.reset()
        self.place_frame4.reset()
        self.place_frame5.reset()
        self.place_frame6.reset()
        self.place_frame7.reset()
        self.place_frame8.reset()
        self.place_frame9.reset()

    def add_num(self, event=None):
        if self.num == 9:
            self.num -= 9
            self.reset_all_frames()
        else:
            self.num += 1

        self.winner = self.check_winner()

        if self.winner is not None or self.num == 9:
            self.master.after(1000, self.delayed_reset)
            self.func(self.winner)
            self.func2()
            return

        self.func(self.winner)

    def delayed_reset(self):

        self.reset_all_frames()
        self.num = 0
        self.winner = None

        self.func(None)

    def return_winner(self):
        return self.winner
