import customtkinter as ctk
import PIL.Image as Img


class PlaceFrame(ctk.CTkFrame):
    def __init__(self, master, x_img, o_img, current_player_var, **kwargs):
        # Initialize the frame and setup layout
        super().__init__(master, **kwargs)

        # griding
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # objects
        self.current_player_var = current_player_var
        self.is_occupied = False
        self.value = None
        self.x_img = x_img
        self.o_img = o_img

        img = Img.new('RGB', (64, 64), color='gray')
        self.none_img = ctk.CTkImage(img, size=(64, 64))

        self.img_lbl = ctk.CTkLabel(
            self,
            image=self.none_img,
            text='',
            cursor="hand2"
        )
        self.img_lbl.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)

        self.img_lbl.bind("<Button-1>", self.click)
        self.bind("<Button-1>", self.click)

    def click(self, event=None):
        if not self.is_occupied:
            if self.current_player_var.get() == 'X':
                self.img_lbl.configure(image=self.x_img)
                self.value = 'X'
            else:
                self.img_lbl.configure(image=self.o_img)
                self.value = 'O'

            self.is_occupied = True

            if self.current_player_var.get() == 'X':
                self.current_player_var.set('O')
            else:
                self.current_player_var.set('X')

    def reset(self):
        self.img_lbl.configure(image=self.none_img)
        self.is_occupied = False
        self.value = None

    def return_state(self):
        return self.value

    def is_empty(self):
        return not self.is_occupied
