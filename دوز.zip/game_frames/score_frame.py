import customtkinter as ctk
import tkinter.messagebox as sms


class ScoreFrame(ctk.CTkFrame):
    def __init__(self, master, x, o, **kwargs):
        super().__init__(master, **kwargs)

        # griding
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1), weight=1)

        # objects
        self.persian_font = ctk.CTkFont('Arabic Typesetting', 100, 'bold')

        self.player_img_X = x
        self.player_img_O = o

        self.winner = None

        self.score_X = 0
        self.score_X_img_lbl = ctk.CTkLabel(self, text='', image=self.player_img_X)
        self.score_X_lbl = ctk.CTkLabel(self, text=f': {self.score_X}', font=self.persian_font)
        self.score_X_img_lbl.grid(column=0, row=0, sticky='nsew')
        self.score_X_lbl.grid(column=1, row=0, sticky='nsew')

        self.score_O = 0
        self.score_O_img_lbl = ctk.CTkLabel(self, text='', image=self.player_img_O)
        self.score_O_lbl = ctk.CTkLabel(self, text=f': {self.score_O}', font=self.persian_font)
        self.score_O_img_lbl.grid(column=0, row=1, sticky='nsew')
        self.score_O_lbl.grid(column=1, row=1, sticky='nsew')

    def add_score(self, winner):
        self.winner = winner
        if winner == 'X':
            self.score_X += 1
            self.score_X_lbl.configure(text=f': {self.score_X}')
        elif winner == 'O':
            self.score_O += 1
            self.score_O_lbl.configure(text=f': {self.score_O}')

    def end_game(self):
        if self.score_X == 10:
            sms.showinfo('بازی تمام شد', 'X برنده شد')
            return True
        elif self.score_O == 10:
            sms.showinfo('بازی تمام شد', 'O برنده شد')
            return True
        else:
            return False
