from customtkinter import *
from game_frame import GameFrame

game = CTk()

game.title('دوز')
game.geometry("600x800+0+0")

# griding
game.grid_columnconfigure(0, weight=1)
game.grid_rowconfigure(tuple(i for i in range(10)), weight=1)

# objects
persian_font = CTkFont('Arabic Typesetting', 100, 'bold')

game_name = CTkLabel(game, text='دوز', font=persian_font)
game_name.grid(column=0, row=0, padx=10, pady=10, sticky='nsew')

game_frame = GameFrame(game)
game_frame.grid(column=0, row=1, padx=10, pady=10, sticky='nsew', rowspan=9)


def mainloop():
    game.mainloop()


if __name__ == '__main__':
    mainloop()
