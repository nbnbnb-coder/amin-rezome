import customtkinter as ctk
import PIL.Image as Img
from game_frames.player_frame import PlayerFrame
from game_frames.score_frame import ScoreFrame
from game_frames.main_frame import MainFrame
import random as rnd
import sys
import os


class GameFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        # griding
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=4)

        # objects
        def resource_path(relative_path):
            try:
                # حالت PyInstaller
                base_path = sys._MEIPASS
            except AttributeError:
                # حالت توسعه
                base_path = os.path.abspath(".")

            return os.path.join(base_path, relative_path)

        self.__size = (64, 64)
        self.player_img_X = ctk.CTkImage(Img.open(resource_path('game_frames/images/1.1.png')), size=self.__size)
        self.player_img_O = ctk.CTkImage(Img.open(resource_path('game_frames/images/1.2.png')), size=self.__size)
        self.randomize = rnd.randint(0, 100)
        self.current_player = ctk.StringVar(value='X')

        self.player_frame = PlayerFrame(self, self.player_img_X, self.player_img_O, self.current_player,
                                        fg_color='transparent')
        self.player_frame.grid(column=0, row=0, padx=10, pady=10, sticky='nsew')

        self.score_frame = ScoreFrame(self, self.player_img_X, self.player_img_O)
        self.score_frame.grid(column=1, row=0, padx=10, pady=10, sticky='new')

        self.main_frame = MainFrame(self, self.player_img_X, self.player_img_O, self.current_player,
                                    self.score_frame.add_score,
                                    self.end_game,
                                    fg_color='transparent')
        self.main_frame.grid(column=0, row=1, padx=10, pady=10, sticky='nsew', columnspan=2)

    def end_game(self):
        if self.score_frame.end_game():
            self.master.destroy()
