import tkinter as tk


class Btn(tk.Button):
	def __init__(self, master, key, func, column, row):
		self.key = str(key)
		super().__init__(master, text=self.key,
		command=lambda: func(self.key), width=7, height=1
		)
		self.grid(column=column, row=row)