from tkinter import *
from Classes import Btn

exp = ""


def p(key):
    global exp
    exp += key
    equ.set(exp)


def ep(v):
    try:
        global exp
        t = str(eval(exp))
        equ.set(t)
        exp = ""
    except:
        equ.set(" error ")
        exp = ""


def c(v):
    global exp
    exp = ""
    equ.set("")


if __name__ == "__main__":
    app = Tk()
    app.config(bg="yellow")
    app.title("Calculator")
    equ = StringVar()
    e = Entry(app, textvariable=equ)
    e.grid(columnspan=4, ipadx=70)
    b1 = Btn(app, 1, p, 0, 2)
    b2 = Btn(app, 2, p, 1, 2)
    b3 = Btn(app, 3, p, 2, 2)
    b4 = Btn(app, 4, p, 0, 3)
    b5 = Btn(app, 5, p, 1, 3)
    b6 = Btn(app, 6, p, 2, 3)
    b7 = Btn(app, 7, p, 0, 4)
    b8 = Btn(app, 8, p, 1, 4)
    b9 = Btn(app, 9, p, 2, 4)
    b0 = Btn(app, 0, p, 0, 5)
    b = Btn(app, "+", p, 3, 2)
    m = Btn(app, "-", p, 3, 3)
    z = Btn(app, "*", p, 3, 4)
    t = Btn(app, "/", p, 3, 5)
    n = Btn(app, ".", p, 2, 5)
    c = Btn(app, "clear", c, 1, 5)
    be = Btn(app, "=", ep, 0, 6)
    app.mainloop()
